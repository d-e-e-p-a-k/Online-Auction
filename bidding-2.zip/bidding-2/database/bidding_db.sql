-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2022 at 04:56 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bidding_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE `bids` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `bid_amount` float NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=bid,2=confirmed,3=cancelled',
  `date_created` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bids`
--

INSERT INTO `bids` (`id`, `user_id`, `product_id`, `bid_amount`, `status`, `date_created`) VALUES
(2, 5, 1, 7500, 1, '2020-10-27 14:18:50'),
(4, 5, 3, 155000, 1, '2020-10-27 16:37:29'),
(5, 1, 4, 2000, 1, '2022-11-10 17:40:59'),
(6, 6, 4, 5000, 1, '2022-11-10 17:42:39'),
(7, 7, 4, 10000, 1, '2022-11-10 17:44:20'),
(8, 6, 4, 12000, 1, '2022-11-10 17:45:02'),
(9, 1, 5, 3000, 1, '2022-11-10 20:44:57'),
(10, 6, 8, 1100, 1, '2022-11-11 15:15:36'),
(11, 8, 8, 1300, 1, '2022-11-11 15:18:57'),
(12, 1, 9, 200, 1, '2022-11-17 13:59:08'),
(13, 6, 9, 201, 1, '2022-11-17 16:13:05'),
(14, 27, 4, 12000, 1, '2022-11-17 16:30:40'),
(15, 6, 13, 400, 1, '2022-11-17 20:06:23');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(30) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(2, 'Mens Wear'),
(3, 'Womens Wear'),
(4, 'Kids Wear'),
(5, 'Accessories'),
(6, 'Footwear'),
(7, 'Shoes');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `start_bid` float NOT NULL,
  `regular_price` float NOT NULL,
  `bid_end_datetime` datetime NOT NULL,
  `img_fname` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `start_bid`, `regular_price`, `bid_end_datetime`, `img_fname`, `date_created`) VALUES
(4, 2, 'Blue Shirt', 'Blue XL Shirt', 400, 1500, '2022-12-01 19:00:00', '4.jpg', '2022-11-10 17:40:33'),
(5, 2, 'Black Hoodie', 'Size:XL', 200, 3000, '2022-11-19 19:50:00', '5.jpg', '2022-11-10 20:41:54'),
(6, 2, 'Blue Trendy Shirt', 'Size: L\r\nFabric: Cotton', 200, 2000, '2022-11-16 19:00:00', '6.jpg', '2022-11-11 11:40:50'),
(7, 3, 'Stop Black Hoodie', 'Size: L\r\nRelaxed, good for winters', 800, 2000, '2022-11-17 21:00:00', '7.jpg', '2022-11-11 11:45:15'),
(8, 6, 'Adidas Black Sneakers', 'Size: UK-10', 1000, 4500, '2022-11-24 15:33:00', '8.jpg', '2022-11-11 11:47:54'),
(9, 3, 'Max Red Top', 'Size: L\r\n', 100, 1000, '2022-11-25 15:33:00', '9.jpg', '2022-11-11 11:49:12'),
(10, 5, 'Tissot Watch', '1853 Black & Gold Edition', 8500, 22000, '2022-11-18 15:33:00', '10.jpg', '2022-11-11 11:51:15'),
(11, 3, 'White Hoodie', 'Size: XL', 100, 1100, '2022-11-11 17:00:00', '11.jpg', '2022-11-11 11:52:23'),
(12, 4, 'Woven Art Silk Jacquard Kurta Set', 'Readymade Art Silk Jacquard Kurta in Navy Blue\r\nThis Collar Neck and Full Sleeve attire is Allured with Moulded Buttons and Resham Work\r\nAvailable with an Art Dupion Silk Churidar in Dark Beige\r\nDo Note: Accessories shown in the image are for presentation purposes only. Half to one inch may vary in measurement. (Slight variation in actual colour vs. image is possible.)', 2000, 4500, '2022-11-16 14:00:00', '12.jpg', '2022-11-11 11:55:17'),
(13, 2, 'Shirt', 'Size:L', 300, 2000, '2022-11-17 20:23:00', '13.jpg', '2022-11-11 15:13:46'),
(14, 2, 'White Hoodie', 'size:L', 100, 1500, '2022-11-16 23:42:00', '14.jpg', '2022-11-15 23:42:51');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'Drippy City', 'info@drip.com', '1800-1234-00', '1668146640_c1.jpg', '&lt;h5 style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; text-align: justify;&quot;&gt;&lt;b style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; text-align: justify;&quot;&gt;Thrifting &lt;/b&gt;&lt;/span&gt;&lt;span style=&quot;text-align: justify;&quot;&gt;&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;is about more than just finding amazing deals on your &lt;/font&gt;favourite&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;brands. It&rsquo;s about shopping with intention, rejecting throwaway fashion culture, and standing for sustainability. The clothes we wear have the power to create &lt;/font&gt;change. Thrifting&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;Can Help Solve the Fashion Waste &lt;/font&gt;Crisis. Our&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;love for constant newness has come at too high a price for our planet. Shopping second-hand reduces the cost of fashion by giving new life to used clothes. Resale moves us one step closer to a circular fashion future. We created a smarter way to shop and &lt;/font&gt;sell. We&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;deliver a modern resale experience on one of the largest online platforms for women&rsquo;s and kids&rsquo; &lt;/font&gt;second-hand&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;apparel, providing a fun and convenient place to shop and clean out your closet.55K &lt;/font&gt;brands from&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;Gap to &lt;/font&gt;Gucci Up&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;to 90% &lt;/font&gt;off estimated&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;retail price. Nowadays, Thrift Shopping is booming. We collaborative as a team thought why not sell second hand clothes at the cost of &lt;/font&gt;bidding.&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;It&rsquo;s basically a &lt;/font&gt;Thrift&lt;font color=&quot;#000000&quot; face=&quot;Open Sans, Arial, sans-serif&quot;&gt;&amp;nbsp;Store but online.&lt;/font&gt;&lt;/span&gt;&lt;br&gt;&lt;/h5&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1=Admin,2=Subscriber',
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `email`, `contact`, `address`, `type`, `date_created`) VALUES
(1, 'Administrator', 'admin', '0192023a7bbd73250516f069df18b500', 'admin@admin.com', '+123456789', '', 1, '2020-10-27 09:19:59'),
(6, 'Deepak', 'deepak', '3b8f9fa2e58b5e835028f1dafc2de1fa', 'ardeepakreddy@gmail.com', '9888888888', 'VIT VELLORE', 2, '2022-11-10 17:42:05'),
(26, 'advaith', 'Advaith', 'ea870eaeb9219a8e862936f382362412', 'advaith.srivatsatv@gmail.com', '8888888888', 'AAAA', 2, '2022-11-17 16:13:58'),
(27, 'Tanishq', 'tanishq', '81dc9bdb52d04dc20036dbd8313ed055', 'tanishq.dang@gmail.com', '9876543210', '10 Shri Murali Nagar\r\nMinjur 601203', 2, '2022-11-17 16:30:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bids`
--
ALTER TABLE `bids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bids`
--
ALTER TABLE `bids`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
